Coloque aqui ícones customizados (SVG/PNG) que não sejam do Font Awesome.
